"""A small Flask + SQLite job application portal for a classroom demo."""

from contextlib import contextmanager
from datetime import datetime, timezone
import os
from pathlib import Path
import re
import sqlite3

from flask import Flask, jsonify, render_template, request

app = Flask(__name__)
ROOT = Path(__file__).resolve().parent
configured_database = os.environ.get("DATABASE_PATH")
DATABASE_PATH = Path(configured_database).expanduser() if configured_database else ROOT / "instance" / "job_portal.sqlite3"

SAMPLE_JOBS = [
    {"title": "Junior Frontend Developer", "department": "Product & Engineering", "location": "Remote · India", "type": "Full-time", "description": "Help turn thoughtful product ideas into clear, accessible web experiences. You will work with designers and engineers who enjoy learning together.", "skills": ["HTML", "CSS", "JavaScript"]},
    {"title": "Python Intern", "department": "Product & Engineering", "location": "Bengaluru · Hybrid", "type": "Internship", "description": "Build and improve small backend features, work with APIs, and learn how a modern product team ships reliable software.", "skills": ["Python", "Flask", "SQL"]},
    {"title": "Product Design Intern", "department": "Design", "location": "Remote · India", "type": "Internship", "description": "Support the design team with research, wireframes, and polished interface details that make everyday work feel easier.", "skills": ["Figma", "Prototyping", "Research"]},
    {"title": "People Operations Coordinator", "department": "People", "location": "Mumbai · Hybrid", "type": "Full-time", "description": "Help create a welcoming candidate and employee experience by coordinating interviews, onboarding, and team programs.", "skills": ["Communication", "Organization", "People"]},
    {"title": "Content Writing Intern", "department": "Marketing", "location": "Remote · India", "type": "Internship", "description": "Write clear, useful stories for our blog and product pages, collaborating with a friendly marketing team.", "skills": ["Writing", "Editing", "Research"]},
]


@contextmanager
def database():
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def initialize_database():
    with database() as connection:
        connection.execute("""CREATE TABLE IF NOT EXISTS jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            department TEXT NOT NULL,
            location TEXT NOT NULL,
            job_type TEXT NOT NULL,
            description TEXT NOT NULL,
            skills TEXT NOT NULL
        )""")
        connection.execute("""CREATE TABLE IF NOT EXISTS applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER NOT NULL REFERENCES jobs(id),
            applicant_name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL DEFAULT '',
            cover_letter TEXT NOT NULL,
            created_at TEXT NOT NULL
        )""")
        job_count = connection.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]
        if job_count == 0:
            connection.executemany(
                """INSERT INTO jobs (title, department, location, job_type, description, skills)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                [(job["title"], job["department"], job["location"], job["type"], job["description"], ",".join(job["skills"])) for job in SAMPLE_JOBS],
            )


def job_to_dict(row):
    return {"id": row["id"], "title": row["title"], "department": row["department"], "location": row["location"], "type": row["job_type"], "description": row["description"], "skills": row["skills"].split(",") if row["skills"] else []}


@app.get("/")
def home():
    return render_template("index.html")


@app.get("/admin")
def admin():
    return render_template("admin.html")


@app.get("/healthz")
def health_check():
    return jsonify({"status": "ok"})


@app.get("/api/jobs")
def list_jobs():
    with database() as connection:
        rows = connection.execute("SELECT * FROM jobs ORDER BY id").fetchall()
    return jsonify([job_to_dict(row) for row in rows])


@app.post("/api/applications")
def create_application():
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify({"error": "Please send a valid application."}), 400

    name, email, phone, cover_letter = (payload.get(key, "") for key in ("name", "email", "phone", "cover_letter"))
    if not all(isinstance(value, str) for value in (name, email, phone, cover_letter)):
        return jsonify({"error": "Please check the information in each field."}), 400
    name, email, phone, cover_letter = name.strip(), email.strip().lower(), phone.strip(), cover_letter.strip()

    if not 2 <= len(name) <= 80:
        return jsonify({"error": "Name must be between 2 and 80 characters."}), 400
    if len(email) > 254 or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
        return jsonify({"error": "Enter a valid email address."}), 400
    if len(phone) > 40:
        return jsonify({"error": "Phone number must be 40 characters or fewer."}), 400
    if not 20 <= len(cover_letter) <= 3000:
        return jsonify({"error": "Your note must be between 20 and 3,000 characters."}), 400
    try:
        job_id = int(payload.get("job_id"))
    except (TypeError, ValueError):
        return jsonify({"error": "Choose a valid job before applying."}), 400

    with database() as connection:
        job = connection.execute("SELECT id FROM jobs WHERE id = ?", (job_id,)).fetchone()
        if job is None:
            return jsonify({"error": "That job is no longer available."}), 404
        cursor = connection.execute(
            """INSERT INTO applications (job_id, applicant_name, email, phone, cover_letter, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (job_id, name, email, phone, cover_letter, datetime.now(timezone.utc).isoformat(timespec="seconds")),
        )
    return jsonify({"message": "Application received!", "id": cursor.lastrowid}), 201


@app.get("/api/applications")
def list_applications():
    """Demo-only review endpoint; it intentionally has no authentication."""
    with database() as connection:
        rows = connection.execute("""SELECT applications.id, applications.applicant_name, applications.email,
            applications.phone, applications.cover_letter, applications.created_at, jobs.title AS job_title
            FROM applications JOIN jobs ON jobs.id = applications.job_id
            ORDER BY applications.created_at DESC, applications.id DESC""").fetchall()
    return jsonify([{"id": row["id"], "name": row["applicant_name"], "email": row["email"], "phone": row["phone"], "cover_letter": row["cover_letter"], "created_at": row["created_at"], "job_title": row["job_title"]} for row in rows])


initialize_database()

if __name__ == "__main__":
    # Flask's built-in server is for local development only.
    app.run(debug=True)
