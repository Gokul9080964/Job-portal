const jobGrid = document.querySelector("#job-grid");
const searchInput = document.querySelector("#job-search");
const departmentFilter = document.querySelector("#department-filter");
const roleCount = document.querySelector("#role-count");
const noResults = document.querySelector("#no-results");
const dialog = document.querySelector("#application-dialog");
const applicationForm = document.querySelector("#application-form");
const formMessage = document.querySelector("#form-message");
const submitButton = document.querySelector("#submit-button");
let jobs = [];

function makeElement(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

function renderJobs() {
  const query = searchInput.value.trim().toLowerCase();
  const department = departmentFilter.value;
  const filteredJobs = jobs.filter((job) => {
    const searchableText = [job.title, job.department, job.location, job.type, job.description, ...job.skills].join(" ").toLowerCase();
    return searchableText.includes(query) && (department === "all" || job.department === department);
  });

  jobGrid.replaceChildren();
  roleCount.textContent = `${filteredJobs.length} ${filteredJobs.length === 1 ? "role" : "roles"}`;
  noResults.hidden = filteredJobs.length !== 0;
  for (const [index, job] of filteredJobs.entries()) {
    const card = makeElement("article", `job-card job-card-${index % 3}`);
    const top = makeElement("div", "job-card-top");
    top.append(makeElement("span", "job-department", job.department));
    top.append(makeElement("span", "job-arrow", "↗"));
    const title = makeElement("h3", "job-title", job.title);
    const meta = makeElement("p", "job-meta", `${job.location}  ·  ${job.type}`);
    const description = makeElement("p", "job-description", job.description);
    const skills = makeElement("div", "skill-list");
    for (const skill of job.skills) skills.append(makeElement("span", "skill-chip", skill));
    const applyButton = makeElement("button", "job-apply", "View role & apply →");
    applyButton.type = "button";
    applyButton.addEventListener("click", () => openApplication(job));
    card.append(top, title, meta, description, skills, applyButton);
    jobGrid.append(card);
  }
}

async function loadJobs() {
  try {
    const response = await fetch("/api/jobs");
    if (!response.ok) throw new Error("Could not load roles.");
    jobs = await response.json();
    for (const department of [...new Set(jobs.map((job) => job.department))].sort()) {
      const option = document.createElement("option");
      option.value = department;
      option.textContent = department;
      departmentFilter.append(option);
    }
    renderJobs();
  } catch (error) {
    jobGrid.replaceChildren(makeElement("p", "load-error", "We couldn’t load the roles. Refresh the page and try again."));
    roleCount.textContent = "Roles unavailable";
  }
}

function openApplication(job) {
  document.querySelector("#job-id").value = job.id;
  document.querySelector("#dialog-role").textContent = `${job.title} · ${job.location}`;
  formMessage.textContent = "";
  formMessage.className = "form-message";
  dialog.showModal();
  document.querySelector("#applicant-name").focus();
}

searchInput.addEventListener("input", renderJobs);
departmentFilter.addEventListener("change", renderJobs);
document.querySelector("#dialog-close").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", (event) => {
  if (event.target === dialog) dialog.close();
});

applicationForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(applicationForm).entries());
  payload.job_id = Number(payload.job_id);
  submitButton.disabled = true;
  submitButton.textContent = "Sending…";
  formMessage.textContent = "";
  formMessage.className = "form-message";
  try {
    const response = await fetch("/api/applications", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "We couldn’t send your application.");
    applicationForm.reset();
    formMessage.textContent = "Application received! Your friend can view it in the team dashboard.";
    formMessage.classList.add("success-message");
    setTimeout(() => dialog.close(), 1800);
  } catch (error) {
    formMessage.textContent = error.message;
    formMessage.classList.add("error-message");
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "Send application ↗";
  }
});

loadJobs();
