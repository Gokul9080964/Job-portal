const list = document.querySelector("#application-list");
const count = document.querySelector("#application-count");
const search = document.querySelector("#application-search");
let applications = [];

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function formatDate(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Date unavailable";
  return new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(date);
}

function renderApplications() {
  const query = search.value.trim().toLowerCase();
  const filtered = applications.filter((application) =>
    [application.name, application.email, application.job_title].join(" ").toLowerCase().includes(query)
  );
  count.textContent = String(applications.length);
  list.replaceChildren();
  if (filtered.length === 0) {
    list.append(element("div", "empty-state", applications.length ? "No applications match your search." : "No applications yet. New submissions will show up here."));
    return;
  }

  for (const application of filtered) {
    const card = element("article", "application-card");
    const top = element("div", "application-card-top");
    const identity = element("div", "applicant-identity");
    const avatar = element("span", "applicant-avatar", application.name.trim().slice(0, 1).toUpperCase() || "?");
    const nameBlock = element("div", "applicant-name-block");
    nameBlock.append(element("h2", "applicant-name", application.name));
    nameBlock.append(element("p", "applicant-job", application.job_title));
    identity.append(avatar, nameBlock);
    top.append(identity, element("time", "application-date", formatDate(application.created_at)));

    const contact = element("div", "applicant-contact");
    const email = element("a", "contact-link", application.email);
    email.href = `mailto:${encodeURIComponent(application.email)}`;
    contact.append(email);
    if (application.phone) contact.append(element("span", "contact-phone", application.phone));

    const letter = element("details", "cover-letter-details");
    letter.append(element("summary", "", "Read their note"));
    letter.append(element("p", "cover-letter-text", application.cover_letter));
    card.append(top, contact, letter);
    list.append(card);
  }
}

async function loadApplications() {
  list.replaceChildren(element("div", "empty-state", "Loading applications…"));
  try {
    const response = await fetch("/api/applications");
    if (!response.ok) throw new Error("Could not load applications.");
    applications = await response.json();
    renderApplications();
  } catch (error) {
    count.textContent = "—";
    list.replaceChildren(element("div", "empty-state error-message", "Couldn’t load applications. Please refresh and try again."));
  }
}

search.addEventListener("input", renderApplications);
document.querySelector("#refresh-button").addEventListener("click", loadApplications);
loadApplications();
