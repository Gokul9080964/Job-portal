# Northstar Job Application Portal

A responsive demo job portal made with HTML, CSS, vanilla JavaScript, Python (Flask), and SQLite. It runs locally in VS Code and can be published from GitHub to Render.

## Project plan

1. **Frontend:** `templates/index.html` and `static/styles.css` make the careers page and application form. `static/app.js` loads jobs and submits applications.
2. **Backend:** `app.py` uses Flask to serve the pages and provide JSON endpoints.
3. **Database:** SQLite is built into Python. The database and five sample jobs are created automatically on the first run. Local applications are stored in `instance/job_portal.sqlite3`.
4. **Review page:** `/admin` displays submitted demo applications.
5. **Publishing:** GitHub stores the project source. Render runs the Python app and serves both the frontend and backend.

## Features

- Browse five sample job listings.
- Search listings and filter by department.
- Submit an application with name, email, optional phone, and a short note.
- Review submitted applications in a simple team dashboard.
- Responsive layout for desktop and mobile.
- Server-side validation and parameterized database queries.

## Run it in VS Code

### 1. Install the basics

- Install Python 3.10 or newer.
- Install [Visual Studio Code](https://code.visualstudio.com/) and the Microsoft Python extension.
- Download or clone this project. In VS Code choose **File → Open Folder** and open the project folder.

### 2. Open the VS Code terminal

Choose **Terminal → New Terminal**. From the project folder, run the commands for your operating system.

**macOS / Linux:**

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```

**Windows PowerShell:**

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

If PowerShell blocks activation, use Command Prompt and run `.venv\Scripts\activate.bat`, then continue with the install and run commands. If VS Code asks, choose the Python interpreter inside `.venv`.

When the terminal says the server is running, open **http://127.0.0.1:5000** in your browser. The team dashboard is at **http://127.0.0.1:5000/admin**. Stop the server with **Ctrl+C** in the terminal.

The local SQLite database is created automatically in `instance/`. To reset it, stop the server and delete `instance/job_portal.sqlite3`; the sample jobs will be recreated the next time the app starts.

## Put the project on GitHub

1. Sign in to GitHub and create an empty repository, for example `job-application-portal`, without a README, license, or `.gitignore`.
2. This project folder already has a local Git repository and an initial commit. In the VS Code terminal, from this project folder, connect it to the GitHub repository and push:

```bash
git remote add origin https://github.com/YOUR-USERNAME/job-application-portal.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username and use the repository URL GitHub shows. GitHub may ask you to sign in through your browser. For later changes, run `git add .`, `git commit -m "Describe the change"`, then `git push`.

If you copied the source into a new folder without its `.git` directory, initialize Git and create the first commit before connecting the remote: run `git init`, `git add .`, `git commit -m "Build job application portal demo"`, then `git branch -M main`.

## Publish a working site

GitHub Pages serves static files; it does not run this Python backend. The included `render.yaml` lets Render build the Flask app directly from your GitHub repository.

1. Push the project to GitHub using the steps above.
2. Sign in to [Render](https://render.com/) and connect your GitHub account.
3. In Render choose **New → Blueprint**, then select this repository. Render reads `render.yaml` and creates the web service. If you create a Web Service manually instead, use:
   - Build command: `pip install -r requirements.txt`
   - Start command: `gunicorn app:app`
   - Health check path: `/healthz`
4. Wait for the deploy, then open the `onrender.com` URL shown in the Render dashboard. Each push to the connected branch triggers another deploy.

**Demo database note:** the hosted demo uses SQLite at `/tmp/job_portal.sqlite3`. Render's free web services can spin down when idle, and their local files are temporary, so hosted applications may disappear after a restart, spin-down, or redeploy. This is fine for a short demonstration. The SQLite database on your computer stays in `instance/` until you remove it.

## Useful URLs

- Careers page: `/`
- Team dashboard: `/admin`
- Jobs API: `/api/jobs`
- Applications API: `/api/applications`
- Health check: `/healthz`

## Demo limitations

This is a learning project. The `/admin` page and applications API do not require a login, so anyone who can reach the hosted site can see submitted information. Use fictional/sample details only. Do not use it to collect real resumes, sensitive information, or real job applications. The demo does not include file uploads, email notifications, or user accounts.
